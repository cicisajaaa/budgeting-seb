<?php

namespace App\Http\Controllers\Admin;


use App\Http\Controllers\Controller;

use App\Models\Proyek;
use App\Models\Perusahaan;

use Illuminate\Http\Request;

use App\Helpers\AuditHelper;

use Maatwebsite\Excel\Facades\Excel;
use App\Imports\ProjectImport;

class ProjectController extends Controller
{


    /*
    |--------------------------------------------------------------------------
    | LIST PROJECT
    |--------------------------------------------------------------------------
    */

    public function index(Request $request)
    {


        $projects = Proyek::with('perusahaan')


            // SEARCH PROJECT
            ->when($request->search, function($query) use ($request){


                $query->where(function($q) use ($request){


                    $q->where(
                        'nama_proyek',
                        'like',
                        '%'.$request->search.'%'
                    )


                    ->orWhere(
                        'pemilik_proyek',
                        'like',
                        '%'.$request->search.'%'
                    )


                    ->orWhereHas(
                        'perusahaan',
                        function($perusahaan) use ($request){


                            $perusahaan->where(
                                'nama_perusahaan',
                                'like',
                                '%'.$request->search.'%'
                            );


                        }
                    );


                });


            })



            // FILTER PERUSAHAAN
            ->when($request->perusahaan_id, function($query) use ($request){


                $query->where(
                    'perusahaan_id',
                    $request->perusahaan_id
                );


            })



            ->latest()

            ->get();






        $perusahaans = Perusahaan::where(
            'status',
            'aktif'
        )->get();






        return view(

            'admin.projects.index',

            compact(

                'projects',

                'perusahaans'

            )

        );


    }









    /*
    |--------------------------------------------------------------------------
    | FORM TAMBAH PROJECT
    |--------------------------------------------------------------------------
    */


    public function create()
    {


        $perusahaans = Perusahaan::where(
            'status',
            'aktif'
        )->get();



        return view(

            'admin.projects.create',

            compact('perusahaans')

        );


    }









    /*
    |--------------------------------------------------------------------------
    | SIMPAN PROJECT
    |--------------------------------------------------------------------------
    */


    public function store(Request $request)
    {


        $request->validate([


            'perusahaan_id'=>'required|exists:perusahaans,id',


            'nama_proyek'=>'required|string|max:255',


            'tanggal_mulai'=>'required|date',


            'tanggal_selesai'=>'nullable|date',


            'pemilik_proyek'=>'nullable|string|max:255',


            'total_anggaran'=>'required|numeric|min:0',



        ]);







        $project = Proyek::create([


            'perusahaan_id'=>$request->perusahaan_id,


            'nama_proyek'=>$request->nama_proyek,


            'tanggal_mulai'=>$request->tanggal_mulai,


            'tanggal_selesai'=>$request->tanggal_selesai,


            'pemilik_proyek'=>$request->pemilik_proyek,


            'total_anggaran'=>$request->total_anggaran,


        ]);







        AuditHelper::create(

            'Tambah Project',

            'Manajemen Project',

            'Admin menambahkan project '.$project->nama_proyek

        );







        return redirect()

            ->route('admin.projects.index')

            ->with(

                'success',

                'Project berhasil ditambahkan'

            );


    }









    /*
    |--------------------------------------------------------------------------
    | DETAIL PROJECT
    |--------------------------------------------------------------------------
    */


    public function show(Proyek $project)
    {


        $project->load([


            'perusahaan',

            'tugas',

            'alokasiDivisi',

            'users'


        ]);





        return view(

            'admin.projects.show',

            compact('project')

        );


    }









    /*
    |--------------------------------------------------------------------------
    | FORM EDIT PROJECT
    |--------------------------------------------------------------------------
    */


    public function edit(Proyek $project)
    {


        $perusahaans = Perusahaan::where(
            'status',
            'aktif'
        )->get();





        return view(

            'admin.projects.edit',

            compact(

                'project',

                'perusahaans'

            )

        );


    }









    /*
    |--------------------------------------------------------------------------
    | UPDATE PROJECT
    |--------------------------------------------------------------------------
    */


    public function update(Request $request, Proyek $project)
    {


        $request->validate([


            'perusahaan_id'=>'required|exists:perusahaans,id',


            'nama_proyek'=>'required|string|max:255',


            'tanggal_mulai'=>'required|date',


            'tanggal_selesai'=>'nullable|date',


            'pemilik_proyek'=>'nullable|string|max:255',


            'total_anggaran'=>'required|numeric|min:0',



        ]);







        $project->update([


            'perusahaan_id'=>$request->perusahaan_id,


            'nama_proyek'=>$request->nama_proyek,


            'tanggal_mulai'=>$request->tanggal_mulai,


            'tanggal_selesai'=>$request->tanggal_selesai,


            'pemilik_proyek'=>$request->pemilik_proyek,


            'total_anggaran'=>$request->total_anggaran,



        ]);







        AuditHelper::create(

            'Update Project',

            'Manajemen Project',

            'Admin memperbarui project '.$project->nama_proyek

        );







        return redirect()

            ->route('admin.projects.index')

            ->with(

                'success',

                'Project berhasil diperbarui'

            );


    }


/*
|--------------------------------------------------------------------------
| IMPORT PROJECT EXCEL
|--------------------------------------------------------------------------
*/

public function import(Request $request)
{


    $request->validate([

        'file'=>'required|mimes:xlsx,xls'

    ]);



    Excel::import(

        new ProjectImport,

        $request->file('file')

    );



    AuditHelper::create(

        'Import Project',

        'Manajemen Project',

        'Admin melakukan import data project dari Excel'

    );




    return redirect()

        ->route('admin.projects.index')

        ->with(

            'success',

            'Data project berhasil diimport'

        );


}






    /*
    |--------------------------------------------------------------------------
    | DELETE PROJECT
    |--------------------------------------------------------------------------
    */


    public function destroy(Proyek $project)
    {


        if(

            $project->tugas()->count() > 0 ||

            $project->alokasiDivisi()->count() > 0 ||

            $project->users()->count() > 0 ||

            $project->setoranProyek()->count() > 0 ||

            $project->pengajuanDana()->count() > 0 ||

            $project->transaksiDana()->count() > 0


        ){


            return back()->withErrors([


                'project'=>

                'Project tidak dapat dihapus karena masih memiliki tugas, anggota, alokasi, atau transaksi.'



            ]);


        }







        AuditHelper::create(

            'Hapus Project',

            'Manajemen Project',

            'Admin menghapus project '.$project->nama_proyek

        );







        $project->delete();







        return redirect()

            ->route('admin.projects.index')

            ->with(

                'success',

                'Project berhasil dihapus'

            );


    }



}