<?php

namespace App\Http\Controllers\Admin;


use App\Http\Controllers\Controller;


use App\Helpers\AuditHelper;
use App\Models\User;
use App\Models\Karyawan;
use App\Models\Divisi;
use App\Models\LogAudit;


use Illuminate\Validation\Rule;
use Illuminate\Http\Request;

use Illuminate\Support\Facades\Hash;



class UserController extends Controller
{


    /*
    |--------------------------------------------------------------------------
    | LIST USER
    |--------------------------------------------------------------------------
    */

public function index(Request $request)
{


    $users = User::with([
        'karyawan.divisi'
    ])

    ->when(
        $request->role,
        function($query) use ($request){

            $query->where(
                'role',
                $request->role
            );

        }
    )


    ->when(
        $request->search,
        function($query) use ($request){

            $query->where(function($q) use ($request){

                $q->where(
                    'name',
                    'like',
                    '%'.$request->search.'%'
                )

                ->orWhere(
                    'email',
                    'like',
                    '%'.$request->search.'%'
                );

            });

        }
    )


    ->latest()

    ->get();


        $totalUser = User::count();



        $totalAdmin = User::where(
            'role',
            'admin'
        )->count();

        $totalOwner = User::where(
            'role',
            'owner'
        )->count();


        $totalKeuangan = User::where(
            'role',
            'keuangan'
        )->count();


        $totalKaryawanOnly = User::where(
            'role',
            'karyawan'
        )->count();


        $totalKaryawan = User::whereIn(
            'role',
            [
                'admin',
                'keuangan',
                'karyawan'
            ]
        )->count();




        $totalProject = \App\Models\Proyek::count();


        $totalTask = \App\Models\Tugas::count();


        $totalDivision = Divisi::count();




        $totalExpenseRequest = \App\Models\PengajuanDana::count();



        $totalPendingExpense = \App\Models\PengajuanDana::where(
            'status',
            'pending'
        )->count();



        $totalApprovedExpense = \App\Models\PengajuanDana::where(
            'status',
            'disetujui'
        )->count();



        $totalRejectedExpense = \App\Models\PengajuanDana::where(
            'status',
            'ditolak'
        )->count();





        $recentProjects = \App\Models\Proyek::latest()
            ->limit(5)
            ->get();





        $recentAudit = LogAudit::with(
            'pengguna'
        )
        ->latest()
        ->limit(5)
        ->get();






        return view(

            'admin.users.index',

            compact(

                'users',

                'totalUser',

                'totalAdmin',

                'totalKaryawan',

                'totalOwner',

                'totalKeuangan',

                'totalKaryawanOnly',

                'totalProject',

                'totalTask',

                'totalDivision',

                'totalExpenseRequest',

                'totalPendingExpense',

                'totalApprovedExpense',

                'totalRejectedExpense',

                'recentProjects',

                'recentAudit'

            )

        );


    }








    /*
    |--------------------------------------------------------------------------
    | CREATE
    |--------------------------------------------------------------------------
    */

    public function create()
    {


        $divisi = Divisi::all();



        return view(

            'admin.users.create',

            compact('divisi')

        );


    }









    /*
    |--------------------------------------------------------------------------
    | STORE
    |--------------------------------------------------------------------------
    */

    public function store(Request $request)
    {


        $request->validate([


            'name'=>'required|string|max:255',


            'email'=>'required|email|unique:users,email',


            'password'=>'required|min:8|confirmed',


            'role'=>[
                'required',
                Rule::in(User::$roles)
            ],


            'nama_karyawan'=>[
                'required_if:role,admin',
                'required_if:role,keuangan',
                'required_if:role,karyawan',
                'string'
            ],

            'divisi_id'=>[
                'required_if:role,admin',
                'required_if:role,keuangan',
                'required_if:role,karyawan',
                'exists:divisi,id'
            ],


        ]);

        if(
            $request->role == 'owner'
            &&
            User::where('role','owner')->exists()
        ){

        return back()
        ->withErrors([
        'role'=>'Owner sudah tersedia'
        ])
        ->withInput();

        }



        $user = User::create([


            'name'=>$request->name,


            'email'=>$request->email,


            'password'=>Hash::make(
                $request->password
            ),


            'role'=>$request->role


        ]);






        // Admin, Keuangan, Karyawan memiliki data karyawan

if(in_array($request->role,[
    'admin',
    'keuangan',
    'karyawan'
]))
{


    Karyawan::create([

        'pengguna_id'=>$user->id,

        'nama_karyawan'=>$request->nama_karyawan
            ?? $request->name,

        'divisi_id'=>$request->divisi_id

    ]);

}



AuditHelper::create(

    'Tambah User',

    'Manajemen User',

    'Admin menambahkan user '.$user->name

);






        return redirect()

            ->route('admin.users.index')

            ->with(

                'success',

                'User berhasil ditambahkan'

            );


    }









    /*
    |--------------------------------------------------------------------------
    | SHOW
    |--------------------------------------------------------------------------
    */


    public function show(User $user)
    {


        $user->load([

            'karyawan.divisi',

            'karyawan.tugas',

            'logAudit',

            'pengajuanDana'

        ]);





        $totalTask = 0;


        $taskSelesai = 0;





        if($user->karyawan)
        {


            $totalTask = $user
                ->karyawan
                ->tugas
                ->count();



            $taskSelesai = $user
                ->karyawan
                ->tugas
                ->where(
                    'status',
                    'selesai'
                )
                ->count();


        }





        $totalPengajuan = $user->pengajuanDana?->count() ?? 0;





        return view(

            'admin.users.show',

            compact(

                'user',

                'totalTask',

                'taskSelesai',

                'totalPengajuan'

            )

        );


    }









    /*
    |--------------------------------------------------------------------------
    | EDIT
    |--------------------------------------------------------------------------
    */

    public function edit(User $user)
    {


        $divisi = Divisi::all();



        $user->load(
            'karyawan.divisi'
        );





        return view(

            'admin.users.edit',

            compact(

                'user',

                'divisi'

            )

        );


    }









    /*
    |--------------------------------------------------------------------------
    | UPDATE
    |--------------------------------------------------------------------------
    */
public function update(Request $request, User $user)
{

    $request->validate([

        'name'=>'required|string|max:255',

        'email'=>'required|email|unique:users,email,'.$user->id,

        'role'=>[
            'required',
            Rule::in(User::$roles)
        ]

    ]);


    if(
        $user->role == 'owner'
        &&
        $request->role != 'owner'
        &&
        User::where('role','owner')
        ->count() <= 1
    ){

        return back()->withErrors([
            'role'=>'Owner utama tidak dapat diubah.'
        ]);

    }


    $user->update([

        'name'=>$request->name,

        'email'=>$request->email,

        'role'=>$request->role

    ]);

if($request->password)
{

    $request->validate([

        'password'=>'min:8'

    ]);


    $user->update([

        'password'=>Hash::make(
            $request->password
        )

    ]);

}



    /*
    |--------------------------------------------------------------------------
    | KELOLA DATA KARYAWAN
    |--------------------------------------------------------------------------
    */


    if(in_array($request->role,[

        'admin',

        'keuangan',

        'karyawan'

    ]))

    {


        $request->validate([


            'nama_karyawan'=>'required|string',


            'divisi_id'=>'required|exists:divisi,id'


        ]);





        Karyawan::updateOrCreate(

            [

                'pengguna_id'=>$user->id

            ],


            [

                'nama_karyawan'=>$request->nama_karyawan,

                'divisi_id'=>$request->divisi_id

            ]

        );


    }
else
{

    if($user->karyawan)
    {

        if(
            $user->karyawan->tugas()->count() > 0 ||
            $user->karyawan->aktivitasTugas()->count() > 0
        )
        {
            return back()
                ->withErrors([
                    'role'=>'User tidak dapat dilepas dari data karyawan karena masih memiliki histori tugas.'
                ]);
        }


        $user->karyawan->delete();

    }

}




    AuditHelper::create(

        'Update User',

        'Manajemen User',

        'Admin memperbarui user '.$user->name

    );






    return redirect()

        ->route('admin.users.index')

        ->with(

            'success',

            'User berhasil diperbarui'

        );

    }


    /*
    |--------------------------------------------------------------------------
    | DELETE
    |--------------------------------------------------------------------------
    */

public function destroy(User $user)
{


    if($user->role == 'owner')
    {

        return back()->withErrors([

            'role'=>'Owner tidak dapat dihapus.'

        ]);

    }



    AuditHelper::create(

        'Hapus User',

        'Manajemen User',

        'Admin menghapus user '.$user->name

    );



    if($user->karyawan)
{

    if(
        $user->karyawan->tugas()->count() > 0 ||
        $user->karyawan->aktivitasTugas()->count() > 0 ||
        $user->karyawan->pengajuanDana()->count() > 0
    )
    {
        return back()
            ->withErrors([
                'user'=>'User tidak dapat dihapus karena masih memiliki histori transaksi atau tugas.'
            ]);
    }


    $user->karyawan->delete();

}


$user->delete();



    return redirect()

        ->route('admin.users.index')

        ->with(

            'success',

            'User berhasil dihapus'

        );


}



}