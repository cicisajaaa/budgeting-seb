<?php

namespace App\Models;


use Illuminate\Database\Eloquent\Model;


class ExpenseTransaction extends Model
{


    protected $table = 'transaksi_dana';




    protected $fillable = [


        'pengajuan_dana_id',

        'disetujui_oleh',

        'rekening_bank_id',

        'jumlah',

        'tanggal',


    ];






    protected $casts = [


        'jumlah'=>'decimal:2',

        'tanggal'=>'date',


    ];








    /*
    |--------------------------------------------------------------------------
    | Relasi Pengajuan Dana
    |--------------------------------------------------------------------------
    */


    public function pengajuanDana()
    {

        return $this->belongsTo(

            ExpenseRequest::class,

            'pengajuan_dana_id'

        );

    }








    /*
    |--------------------------------------------------------------------------
    | Relasi Penyetuju
    |--------------------------------------------------------------------------
    */


    public function penyetuju()
    {

        return $this->belongsTo(

            User::class,

            'disetujui_oleh'

        );

    }








    /*
    |--------------------------------------------------------------------------
    | Relasi Rekening Bank
    |--------------------------------------------------------------------------
    */


    public function rekeningBank()
    {

        return $this->belongsTo(

            BankAccount::class,

            'rekening_bank_id'

        );

    }



}