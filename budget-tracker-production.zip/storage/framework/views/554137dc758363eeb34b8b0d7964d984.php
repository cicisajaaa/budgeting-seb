<?php $__env->startSection('content'); ?>


<div class="glass-panel">


<h2>
Semua Notifikasi
</h2>



<?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>


<a href="<?php echo e(route(
'notification.read',
$notification->id
)); ?>"
style="
display:block;
padding:15px;
background:#f8fafc;
border-radius:15px;
margin-top:10px;
text-decoration:none;
color:#334155;
">


<strong>

<?php echo e($notification->data['title']); ?>


</strong>


<p>

<?php echo e($notification->data['message']); ?>


</p>



<small>

<?php echo e($notification->created_at->diffForHumans()); ?>


</small>



</a>



<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>


<p>
Belum ada notifikasi
</p>


<?php endif; ?>



</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/shahlaqeysha/budget-tracker/resources/views/notification/index.blade.php ENDPATH**/ ?>