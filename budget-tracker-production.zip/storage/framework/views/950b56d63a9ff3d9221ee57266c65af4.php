<?php $__env->startSection('content'); ?>
<div class="card">
    <h2>Input Setoran Baru</h2>
    <p>Project: <strong><?php echo e($project->nama_project); ?></strong></p>

    <form action="<?php echo e(route('deposit.preview', $project->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div style="margin-bottom: 15px;">
            <label>Tanggal Setoran Klien:</label><br>
            <input type="date" name="tanggal_setoran" required style="padding: 8px; width: 100%; max-width: 300px;">
        </div>

        <div style="margin-bottom: 15px;">
            <label>Jumlah Setoran (Rp):</label><br>
            <input type="number" name="jumlah_setoran" required placeholder="Contoh: 30000000" style="padding: 8px; width: 100%; max-width: 300px;">
        </div>

        <button type="submit" class="btn btn-success">Hitung Pembagian Otomatis &rarr;</button>
        <a href="<?php echo e(route('dashboard')); ?>" class="btn" style="background: #6c757d;">Batal</a>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/shahlaqeysha/budget-tracker/resources/views/deposit/create.blade.php ENDPATH**/ ?>