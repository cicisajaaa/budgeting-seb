<!DOCTYPE html>
<html lang="id">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>
Sahabat Eksplorasi Banua
</title>


<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">


<style>

:root{

--primary:#334155;
--primary-dark:#1e293b;
--gold:#64748b;
--cream:#f8fafc;
--sidebar:#0f172a;

--background:#f8fafc;
--text:#334155;

}

*{

margin:0;
padding:0;
box-sizing:border-box;

}



body{

font-family:'Inter',sans-serif;

background:var(--background);

color:var(--text);

font-size:14px;

}



/* ================= SIDEBAR ================= */


.sidebar{

position:fixed;

top:0;

left:0;

bottom:0;

width:230px;

background:var(--sidebar);

padding:20px 15px;

z-index:1000;

}



.brand{

display:flex;

align-items:center;

gap:12px;

padding-bottom:20px;

border-bottom:1px solid rgba(255,255,255,.1);

}



.brand img{

width:42px;

height:42px;

background:white;

padding:5px;

border-radius:8px;

object-fit:contain;

}



.brand-text{

font-size:14px;

font-weight:700;

color:white;

line-height:1.3;

}



.brand-text span{

display:block;

font-size:11px;

color:#94a3b8;

}





.menu-title{

font-size:10px;

font-weight:700;

color:#94a3b8;

margin:25px 10px 10px;

letter-spacing:1px;

}





/* MENU SIDEBAR */

.sidebar a{

    display:flex;

    align-items:center;

    gap:10px;

    height:40px;

    padding:0 12px;

    margin-bottom:6px;

    border-radius:7px;

    text-decoration:none;

    color:#cbd5e1;

    font-size:13px;

    border:none;

    outline:none !important;

    box-shadow:none !important;

    transition:.2s;

    -webkit-tap-highlight-color:transparent;

}




.sidebar a:hover{
background:rgba(148,163,184,.15);
color:white;
}





/* MENU AKTIF */

.sidebar a.active{

    background:#334155;
    border-left:4px solid #94a3b8;

    color:white;

    font-weight:600;

    outline:none !important;

    box-shadow:none !important;

}





/* HILANGKAN EFEK HIJAU BROWSER */

.sidebar a:focus,

.sidebar a:focus-visible,

.sidebar a:active{

    outline:none !important;

    box-shadow:none !important;

    border-color:transparent;

}





.sidebar a.active:focus,
.sidebar a.active:focus-visible{
    border-left:4px solid #94a3b8;
}




.icon{

    width:25px;

    text-align:center;

}





.menu-badge{

    margin-left:auto;

    background:#dc2626;

    color:white;

    padding:3px 7px;

    border-radius:20px;

    font-size:10px;

}




.menu-badge{

margin-left:auto;

background:#dc2626;

color:white;

padding:3px 7px;

border-radius:20px;

font-size:10px;

}



/* STATUS */


.system-status{

position:fixed;

bottom:20px;

left:15px;

width:200px;

background:#111827;

padding:12px;

border-radius:10px;

border:1px solid rgba(255,255,255,.05);

z-index:1001;

}



.system-status-title{

font-size:10px;

color:#94a3b8;

}



.system-online{

display:flex;

align-items:center;

gap:8px;

margin-top:8px;

font-size:12px;

font-weight:600;

color:#d7b787;

}



.online-dot{

width:8px;

height:8px;

background:#22c55e;

box-shadow:0 0 8px #22c55e;

border-radius:50%;

}


</style>

</head>


<body>
<aside class="sidebar">


<div class="brand">

<img src="<?php echo e(asset('images/logo-cv.png')); ?>">


<div class="brand-text">

Sahabat Eksplorasi Banua

<span>
Enterprise Management System
</span>

</div>


</div>




<?php if(in_array(auth()->user()->role,['admin','karyawan'])): ?>

<div class="menu-title">
MAIN
</div>

<a href="
<?php if(auth()->user()->role=='admin'): ?>

<?php echo e(route('admin.dashboard')); ?>


<?php elseif(auth()->user()->role=='karyawan'): ?>

<?php echo e(route('employee.dashboard')); ?>


<?php else: ?>

<?php echo e(route('dashboard')); ?>


<?php endif; ?>

"

class="<?php echo e(request()->routeIs('admin.dashboard') || request()->routeIs('dashboard') || request()->routeIs('employee.dashboard') ? 'active':''); ?>">


<div class="icon">

⌂

</div>

Dashboard

</a>
<?php endif; ?>





<?php if(auth()->user()->role=='admin'): ?>


<div class="menu-title">
MANAGEMENT
</div>


<a href="<?php echo e(route('admin.users.index')); ?>"
class="<?php echo e(request()->routeIs('admin.users.*')?'active':''); ?>">

<div class="icon">
👥
</div>

Kelola Pengguna

</a>




<a href="<?php echo e(route('admin.projects.index')); ?>"
class="<?php echo e(request()->routeIs('admin.projects.*')?'active':''); ?>">

<div class="icon">
📁
</div>

Kelola Project

</a>


<a href="<?php echo e(route('admin.perusahaan.index')); ?>"
class="<?php echo e(request()->routeIs('admin.perusahaan.*')?'active':''); ?>">

<div class="icon">
🏭
</div>

Kelola Perusahaan

</a>


<a href="<?php echo e(route('admin.divisions.index')); ?>"
class="<?php echo e(request()->routeIs('admin.divisions.*')?'active':''); ?>">

<div class="icon">
🏢
</div>

Kelola Divisi

</a>





<a href="<?php echo e(route('admin.tasks.index')); ?>"
class="<?php echo e(request()->routeIs('admin.tasks.*')?'active':''); ?>">

<div class="icon">
📝
</div>

Monitoring Tugas

</a>



<?php endif; ?>











<?php if(auth()->user()->role=='owner'): ?>


<div class="menu-title">
PEMILIK
</div>



<a href="<?php echo e(route('owner.dashboard')); ?>"
class="<?php echo e(request()->routeIs('owner.dashboard')?'active':''); ?>">

<div class="icon">
⌂
</div>

Dashboard Utama

</a>





<a href="<?php echo e(route('owner.projects')); ?>"
class="<?php echo e(request()->routeIs('owner.projects')?'active':''); ?>">

<div class="icon">
📁
</div>

Pemantauan Proyek

</a>





<a href="<?php echo e(route('owner.reports')); ?>"
class="<?php echo e(request()->routeIs('owner.reports')?'active':''); ?>">

<div class="icon">
📊
</div>

Laporan Perusahaan

</a>





<a href="<?php echo e(route('owner.approval')); ?>"
class="<?php echo e(request()->routeIs('owner.approval')?'active':''); ?>">

<div class="icon">
✓
</div>

Monitoring Dana 

</a>





<a href="<?php echo e(route('owner.audit')); ?>"
class="<?php echo e(request()->routeIs('owner.audit')?'active':''); ?>">

<div class="icon">
📝
</div>

Riwayat Aktivitas

</a>



<?php endif; ?>










<?php if(auth()->user()->role=='keuangan'): ?>


<div class="menu-title">
FINANCE
</div>

<a href="<?php echo e(route('finance.dashboard')); ?>"

class="<?php echo e(request()->routeIs('finance.dashboard') || request()->is('finance/dashboard') ? 'active':''); ?>">

<div class="icon">
⌂
</div>

Dashboard Keuangan

</a>


<a href="<?php echo e(route('finance.deposit')); ?>"
class="<?php echo e(request()->routeIs('finance.deposit')?'active':''); ?>">

<div class="icon">
💰
</div>

Pembayaran Masuk

</a>





<a href="<?php echo e(route('finance.bank.index')); ?>"
class="<?php echo e(request()->routeIs('finance.bank.*')?'active':''); ?>">

<div class="icon">
🏦
</div>

Rekening Bank

</a>





<a href="<?php echo e(route('finance.balance')); ?>"
class="<?php echo e(request()->routeIs('finance.balance')?'active':''); ?>">

<div class="icon">
💳
</div>

Saldo Divisi

</a>


<a href="<?php echo e(route('finance.distribution')); ?>"
class="<?php echo e(request()->routeIs('finance.distribution')?'active':''); ?>">

<div class="icon">
📤
</div>

Distribusi Dana

</a>


<a href="<?php echo e(route('finance.expense.index')); ?>"
class="<?php echo e(request()->routeIs('finance.expense.*')?'active':''); ?>">
<div class="icon">
💸
</div>
Riwayat Pengeluaran
</a>

<a href="<?php echo e(route('expense.approval')); ?>"
class="<?php echo e(request()->routeIs('expense.approval')?'active':''); ?>">

<div class="icon">
✓
</div>

Approval Dana

<?php if(isset($pendingApproval) && $pendingApproval > 0): ?>

<span class="menu-badge">

<?php echo e($pendingApproval); ?>


</span>

<?php endif; ?>


</a>



<a href="<?php echo e(route('expense.approval.history')); ?>"
class="<?php echo e(request()->routeIs('expense.approval.history*')?'active':''); ?>">

<div class="icon">
📄
</div>

Riwayat Approval

</a>





<a href="<?php echo e(route('finance.report')); ?>"
class="<?php echo e(request()->routeIs('finance.report')?'active':''); ?>">

<div class="icon">
📊
</div>

Laporan

</a>


<a href="<?php echo e(route('finance.reconciliation')); ?>"

class="<?php echo e(request()->routeIs('finance.reconciliation')?'active':''); ?>">

<div class="icon">

🏦

</div>

Rekonsiliasi Bank

</a>
<?php endif; ?>










<?php if(auth()->user()->role=='karyawan'): ?>


<div class="menu-title">
KARYAWAN
</div>




<a href="<?php echo e(route('expense.create')); ?>"
class="<?php echo e(request()->routeIs('expense.create')?'active':''); ?>">

<div class="icon">
＋
</div>

Pengajuan Dana

</a>




<a href="<?php echo e(route('expense.myhistory')); ?>"
class="<?php echo e(request()->routeIs('expense.myhistory*')?'active':''); ?>">
<div class="icon">
📄
</div>

Riwayat Pengajuan

</a>




<a href="<?php echo e(route('employee.project.index')); ?>"
class="<?php echo e(request()->routeIs('employee.project.*')?'active':''); ?>">

<div class="icon">
📁
</div>

Proyek Saya

</a>




<a href="<?php echo e(route('daily-tracker.index')); ?>"
class="<?php echo e(request()->routeIs('daily-tracker.*')?'active':''); ?>">

<div class="icon">
📝
</div>

Aktivitas Harian

</a>



<?php endif; ?>


<div class="system-status">


<div class="system-status-title">

SYSTEM STATUS

</div>


<div class="system-online">

<div class="online-dot"></div>

System Online

</div>


</div>


</aside>










<header class="header">


<div>
<div class="system-name">
Sistem Manajemen Keuangan

</div>

<div class="header-sub">

<?php if(auth()->user()->role=='owner'): ?>

Dashboard

<?php elseif(auth()->user()->role=='keuangan'): ?>

Dashboard Keuangan

<?php elseif(auth()->user()->role=='admin'): ?>

Dashboard Administrator

<?php else: ?>

Dashboard Karyawan

<?php endif; ?>

</div>

</div>






<div class="profile-area">



<div class="notification">

<button type="button" class="notification-btn" onclick="toggleNotification()">

🔔

<?php if(auth()->user()->unreadNotifications->count()): ?>

<span class="badge">
<?php echo e(auth()->user()->unreadNotifications->count()); ?>

</span>

<?php endif; ?>

</button>




<div class="notification-box">


<?php if(auth()->user()->unreadNotifications->count()): ?>


<?php $__currentLoopData = auth()->user()->unreadNotifications->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php if(Route::has('notification.read')): ?>

<a class="notification-item"
href="<?php echo e(route('notification.read',$notification->id)); ?>">

<?php endif; ?>


<strong>

<?php echo e($notification->data['title']); ?>


</strong>


<p>

<?php echo e($notification->data['message']); ?>


</p>


</a>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<div class="notification-footer">


<form method="POST" action="<?php echo e(route('notifications.readAll')); ?>">

<?php echo csrf_field(); ?>

<button class="read-all">

Tandai semua dibaca

</button>

</form>


</div>

<?php else: ?>


<div class="empty-notif">

Tidak ada notifikasi

</div>


<?php endif; ?>



</div>


</div>






<div class="profile">


<div class="avatar">

<?php echo e(strtoupper(substr(auth()->user()->name,0,1))); ?>


</div>


<div class="profile-info">


<b>

<?php echo e(auth()->user()->name); ?>


</b>


<span>

<?php echo e(ucfirst(auth()->user()->role)); ?>


</span>


</div>


</div>






<form method="POST" action="<?php echo e(route('logout')); ?>">

<?php echo csrf_field(); ?>


<button class="logout">

Keluar

</button>


</form>



</div>


</header>













<main class="content">


<?php if(session('success')): ?>

<div class="alert-success">

<?php echo e(session('success')); ?>


</div>

<?php endif; ?>




<?php if(session('error')): ?>

<div class="alert-error">

<?php echo e(session('error')); ?>


</div>

<?php endif; ?>



<?php echo $__env->yieldContent('content'); ?>



</main>









<style>


/* HEADER */


.header{

position:fixed;

top:0;

left:230px;

right:0;

height:65px;

background:white;

border-bottom:1px solid #e2e8f0;

display:flex;

align-items:center;

justify-content:space-between;

padding:0 25px;

z-index:999;

}


.system-name{
    
font-size:18px;

font-weight:700;

color:#1e293b;

}

.system-name span{

color:#16a34a;

}



.header-sub{

font-size:11px;

color:#64748b;

}



.profile-area{

    display:flex;

    align-items:center;

    gap:18px;

    height:100%;

}



.profile{

display:flex;

align-items:center;

gap:10px;

}


.avatar{

width:38px;

height:38px;

border-radius:50%;

background:#334155;

display:flex;

align-items:center;

justify-content:center;

color:white;

font-weight:700;

}

.profile-info b{

display:block;

font-size:13px;

}



.profile-info span{

font-size:11px;

color:#64748b;


}



.profile-area form{

    margin:0;

    padding:0;

    width:auto;

    height:auto;

    background:none;

    display:flex;

    align-items:center;

}



.logout{

    border:none;

    background:#fee2e2;

    color:#dc2626;

    padding:9px 18px;

    border-radius:10px;

    font-size:13px;

    font-weight:700;

    cursor:pointer;

    width:auto;

    height:auto;

    line-height:normal;

    display:flex;

    align-items:center;

    justify-content:center;

}


.logout:hover{

    background:#fecaca;

}




/* CONTENT */
.content{

    margin-left:230px;

    width:auto;

    min-height:100vh;

    padding:90px 25px 30px;

    box-sizing:border-box;

    overflow-x:hidden;

}
html,
body{

    width:100%;

    overflow-x:hidden;

}


*{

    box-sizing:border-box;

}


/* NOTIFICATION */


.notification{

position:relative;

}


.notification-btn{

width:38px;
height:38px;

border:none;

border-radius:12px;

background:#f8fafc;

display:flex;

justify-content:center;

align-items:center;

cursor:pointer;

position:relative;

font-size:18px;

}

.notification-footer{

border-top:1px solid #e2e8f0;

margin-top:10px;

padding-top:10px;

text-align:right;

}


.read-all{

background:none;

border:none;

color:#2563eb;

font-size:12px;

font-weight:600;

cursor:pointer;

padding:5px;

}


.read-all:hover{

text-decoration:underline;

}

.badge{

position:absolute;

right:-3px;

top:-3px;

background:#dc2626;

color:white;

width:18px;

height:18px;

font-size:10px;

display:flex;

align-items:center;

justify-content:center;

border-radius:50%;

}



.notification-box{

display:none;

position:absolute;

right:0;

top:45px;

width:300px;

background:white;

padding:10px;

box-shadow:0 10px 30px rgba(0,0,0,.15);

border-radius:8px;

}


.notification-box.show{

display:block;

}



.notification-item{

display:block;

background:#f8fafc;

padding:12px;

margin-bottom:8px;

border-radius:6px;

text-decoration:none;

color:#334155;

}



.notification-item strong{

color:#2563eb;

}



.notification-item p{

font-size:12px;

margin-top:5px;

}



.empty-notif{

text-align:center;

padding:20px;

color:#94a3b8;

}





.alert-success{

background:#dcfce7;

color:#166534;

padding:12px;

border-radius:6px;

margin-bottom:20px;

}



.alert-error{

background:#fee2e2;

color:#991b1b;

padding:12px;

border-radius:6px;

margin-bottom:20px;

}
@media(max-width:900px){

.sidebar{
    width:70px;
}


.header{
    left:70px;
}


.content{

    margin-left:70px !important;

    width:auto !important;

}

}



/* FIX ACTIVE SIDEBAR COLOR */

.sidebar a.active,
.sidebar a.active:hover,
.sidebar a.active:focus,
.sidebar a.active:visited{

    color:white !important;

}


.sidebar a.active .icon{

    color:white !important;

}
</style>

<script>

function toggleNotification(){

    let box = document.querySelector('.notification-box');

    box.classList.toggle('show');

}


// klik luar tutup notif

document.addEventListener('click',function(e){

    let notif=document.querySelector('.notification');

    let box=document.querySelector('.notification-box');


    if(
        notif &&
        !notif.contains(e.target)
    ){

        box.classList.remove('show');

    }

});


</script>
</body>

</html><?php /**PATH /Users/shahlaqeysha/budget-tracker/resources/views/layouts/dashboard.blade.php ENDPATH**/ ?>