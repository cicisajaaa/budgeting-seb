<?php $__env->startSection('content'); ?>


<div class="page-header-card">


<div>

<div class="page-label">
TASK DETAIL
</div>


<h1>
<?php echo e($task->nama_tugas); ?>

</h1>


<p>
Detail monitoring pekerjaan, progress, dan informasi pelaksanaan task.
</p>


</div>


<div style="display:flex;gap:10px;">


<?php if($task->status != 'dibatalkan' && $task->status != 'selesai'): ?>


<form action="<?php echo e(route('admin.tasks.cancel',$task->id)); ?>" method="POST">

<?php echo csrf_field(); ?>
<?php echo method_field('PUT'); ?>


<button 
type="submit"
class="btn-cancel"
onclick="return confirm('Yakin ingin membatalkan task ini?')">

❌ Batalkan

</button>


</form>


<?php endif; ?>


<?php if($task->status != 'dibatalkan'): ?>

<a href="<?php echo e(route('admin.tasks.edit',$task->id)); ?>" class="btn-edit">
✏️ Edit
</a>

<?php endif; ?>


<a href="<?php echo e(route('admin.tasks.index')); ?>" class="btn-back">

← Kembali

</a>


</div>

</div>









<div class="detail-grid">








<div class="glass-panel">


<div class="panel-title">

📝 Informasi Task

</div>



<div class="info-list">



<div class="info-item">

<span>
Project
</span>

<strong>

<?php echo e($task->proyek->nama_proyek ?? '-'); ?>


</strong>

</div>



<div class="info-item">
    <span>
        Perusahaan
    </span>

    <strong>
        <?php echo e($task->proyek->perusahaan->nama_perusahaan ?? '-'); ?>

    </strong>
</div>


<div class="info-item">

<span>
PIC
</span>

<strong>

<?php echo e($task->karyawan->nama_karyawan ?? '-'); ?>


</strong>

</div>






<div class="info-item">

<span>
Divisi
</span>

<strong>

<?php echo e($task->divisi->nama_divisi ?? '-'); ?>


</strong>

</div>








<div class="info-item">

<span>
Prioritas
</span>

<strong>

<?php echo e($task->prioritas ?? '-'); ?>


</strong>

</div>







<div class="info-item">

<span>
Deadline
</span>

<strong>

<?php if($task->deadline): ?>

<?php echo e(\Carbon\Carbon::parse($task->deadline)->format('d M Y')); ?>


<?php else: ?>

-

<?php endif; ?>

</strong>

</div>



</div>


</div>











<div class="glass-panel">


<div class="panel-title">

📊 Monitoring Progress

</div>





<div class="status-box">


<span>

Status

</span>


<?php

$statusClass='pending';

$statusLabel='Belum Dimulai';


if($task->status=='selesai'){

    $statusClass='success';
    $statusLabel='Selesai';

}

elseif($task->status=='sedang_dikerjakan'){

    $statusClass='warning';
    $statusLabel='Sedang Dikerjakan';

}

elseif($task->status=='dibatalkan'){

    $statusClass='danger';
    $statusLabel='Dibatalkan';

}

?>



<span class="status-badge <?php echo e($statusClass); ?>">
<?php echo e($statusLabel); ?>

</span>



</div>




<?php
    $progress = min(
        max((float) ($task->progres_persen ?? 0), 0),
        100
    );
?>

<div class="progress-header">

    <span>
        Progress Pekerjaan
    </span>

    <strong>
        <?php echo e(number_format($progress, 0)); ?>%
    </strong>

</div>

<div class="progress-track">

    <div
        class="progress-bar"
        style="width: <?php echo e($progress); ?>%"
    ></div>

</div>



<div class="progress-info">

<?php if($task->status == 'dibatalkan'): ?>

❌ Task dibatalkan


<?php elseif($progress >= 100): ?>

✓ Task selesai


<?php elseif($progress > 0): ?>

⏳ Sedang berjalan


<?php else: ?>

Belum dimulai


<?php endif; ?>


</div>



</div>





</div>








<div class="glass-panel activity-card">


<div class="panel-title">

📌 Aktivitas Pekerjaan

</div>



<div class="description-box">

<?php echo e($task->aktivitas ?? 'Tidak ada aktivitas'); ?>


</div>


</div>







<div class="glass-panel activity-card">

    <div class="panel-title">
        📌 Riwayat Update Aktivitas
    </div>

    <?php $__empty_1 = true; $__currentLoopData = $task->aktivitasTugas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aktivitas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

        <div class="timeline-item">

            
            <div class="timeline-marker"></div>

            
            <div class="timeline-content">

               <div class="timeline-top">

    <div>
        <strong class="timeline-date">
            <?php if($aktivitas->tanggal): ?>
                <?php echo e(\Carbon\Carbon::parse($aktivitas->tanggal)->format('d M Y')); ?>

            <?php else: ?>
                -
            <?php endif; ?>
        </strong>

        <?php if($aktivitas->karyawan): ?>
            <div class="timeline-pic">
                PIC: <?php echo e($aktivitas->karyawan->nama_karyawan); ?>

            </div>
        <?php else: ?>
            <div class="timeline-pic">
                PIC: -
            </div>
        <?php endif; ?>
    </div>

    <span class="timeline-progress">
        <?php echo e(min(max((int) ($aktivitas->progres ?? 0), 0), 100)); ?>%
    </span>

</div>

                <div class="timeline-activity">
                    <?php echo e($aktivitas->aktivitas ?? 'Tidak ada aktivitas'); ?>

                </div>

                <?php if($aktivitas->catatan): ?>

                    <div class="timeline-note">
                        <strong>Catatan:</strong>
                        <?php echo e($aktivitas->catatan); ?>

                    </div>

                <?php endif; ?>

            </div>

        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

        <div class="timeline-empty">
            <div class="timeline-empty-icon">
                📋
            </div>

            <strong>
                Belum ada update aktivitas
            </strong>

            <span>
                Riwayat pekerjaan akan muncul di sini.
            </span>
        </div>

    <?php endif; ?>

</div>






<div class="glass-panel activity-card">


<div class="panel-title">

📝 Catatan

</div>



<div class="description-box">

<?php echo e($task->catatan ?? 'Tidak ada catatan'); ?>



</div>


</div>






<style>

/* ===============================
HEADER
================================ */

.page-header-card{

    background:#f8fafc;

    border:1px solid #e2e8f0;

    border-radius:20px;

    padding:22px 28px;

    display:flex;

    justify-content:space-between;

    align-items:center;

    margin-bottom:20px;

}



.page-label{

    font-size:9px;

    letter-spacing:2px;

    font-weight:800;

    color:#64748b;

}



.page-header-card h1{

    font-size:22px;

    margin:7px 0;

    color:#172033;

    font-weight:800;

}



.page-header-card p{

    margin:0;

    font-size:11px;

    color:#64748b;

}







/* ===============================
BUTTON
================================ */

.btn-back,
.btn-edit{

    padding:8px 16px;

    border-radius:11px;

    text-decoration:none;

    font-size:11px;

    font-weight:700;

    display:inline-flex;

    align-items:center;

    gap:5px;

}

.btn-cancel{

    background:#fee2e2;

    border:1px solid #fecaca;

    color:#dc2626;

    padding:8px 16px;

    border-radius:11px;

    font-size:11px;

    font-weight:700;

    cursor:pointer;

}


.btn-cancel:hover{

    background:#dc2626;

    color:white;

}

.btn-back{

    background:white;

    border:1px solid #e2e8f0;

    color:#334155;

}



.btn-edit{

    background:#dbeafe;

    border:1px solid #bfdbfe;

    color:#2563eb;

}



.btn-edit:hover{

    background:#2563eb;

    color:white;

}



.btn-back:hover{

    background:#1e293b;

    color:white;

}








/* ===============================
GRID
================================ */


.detail-grid{

    display:grid;

    grid-template-columns:1.4fr 1fr;

    gap:18px;

    margin-bottom:18px;

}









/* ===============================
CARD
================================ */


.glass-panel{

    background:white;

    border:1px solid #e5e7eb;

    border-radius:20px;

    padding:20px;

    box-shadow:

    0 6px 20px rgba(15,23,42,.04);

    margin-bottom:18px;

}





.panel-title{

    font-size:15px;

    font-weight:800;

    color:#172033;

    padding-bottom:14px;

    margin-bottom:15px;

    border-bottom:1px solid #f1f5f9;

}









/* ===============================
INFO ITEM
================================ */


.info-item{

    display:flex;

    justify-content:space-between;

    align-items:center;

    padding:11px 12px;

    background:#f8fafc;

    border-radius:12px;

    margin-bottom:9px;

}



.info-item span{

    color:#64748b;

    font-size:11px;

}



.info-item strong{

    color:#172033;

    font-size:11px;

}









/* ===============================
STATUS
================================ */


.status-box{

    display:flex;

    justify-content:space-between;

    align-items:center;

    margin-bottom:18px;

}



.status-box span:first-child{

    font-size:11px;

    color:#64748b;

}



.status-badge{

    padding:6px 12px;

    border-radius:999px;

    font-size:10px;

    font-weight:800;

}





.status-badge.success{

    background:#dcfce7;

    color:#166534;

}





.status-badge.warning{

    background:#fef3c7;

    color:#92400e;

}





.status-badge.pending{

    background:#dbeafe;

    color:#1d4ed8;

}



.status-badge.danger{

    background:#fee2e2;

    color:#dc2626;

}






/* ===============================
PROGRESS
================================ */


.progress-header{

    display:flex;

    justify-content:space-between;

    margin-bottom:8px;

    font-size:11px;

    color:#64748b;

}



.progress-header strong{

    color:#172033;

}



.progress-track{

    width:100%;

    height:7px;

    background:#e2e8f0;

    border-radius:20px;

    overflow:hidden;

}



.progress-bar{

    height:100%;

    background:#334155;

    border-radius:20px;

}



.progress-info{

    margin-top:10px;

    font-size:11px;

    color:#64748b;

}








/* ===============================
DESCRIPTION
================================ */


.description-box{

    background:#f8fafc;

    border:1px solid #e2e8f0;

    padding:14px;

    border-radius:14px;

    color:#475569;

    font-size:12px;

    line-height:1.6;

}



.description-box p{

    font-size:12px;

}








/* ===============================
ACTIVITY
================================ */


.activity-card{

    margin-bottom:18px;

}







/* ===============================
   TIMELINE AKTIVITAS
================================ */

.timeline-item {
    position: relative;
    display: flex;
    gap: 14px;
    padding-bottom: 18px;
}

.timeline-item:last-child {
    padding-bottom: 0;
}

/* GARIS */
.timeline-item:not(:last-child)::before {
    content: "";
    position: absolute;
    left: 5px;
    top: 12px;
    bottom: 0;
    width: 2px;
    background: #e2e8f0;
}

/* TITIK */
.timeline-marker {
    width: 12px;
    height: 12px;
    min-width: 12px;
    margin-top: 4px;
    border-radius: 50%;
    background: #334155;
    border: 3px solid #e2e8f0;
    position: relative;
    z-index: 2;
}

/* CONTENT */
.timeline-content {
    flex: 1;
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 14px;
    padding: 13px 15px;
}

/* HEADER TIMELINE */
.timeline-top {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
    margin-bottom: 8px;
}

.timeline-date {
    font-size: 10px;
    color: #64748b;
}

/* PROGRESS */
.timeline-progress {
    display: inline-flex;
    align-items: center;
    padding: 4px 8px;
    border-radius: 999px;
    background: #dbeafe;
    color: #2563eb;
    font-size: 9px;
    font-weight: 800;
}

/* AKTIVITAS */
.timeline-activity {
    font-size: 12px;
    line-height: 1.6;
    color: #334155;
    font-weight: 600;
}

/* CATATAN */
.timeline-note {
    margin-top: 9px;
    padding-top: 9px;
    border-top: 1px solid #e2e8f0;
    font-size: 10px;
    line-height: 1.5;
    color: #64748b;
}

.timeline-note strong {
    color: #334155;
}

/* EMPTY */
.timeline-empty {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 30px 20px;
    text-align: center;
    background: #f8fafc;
    border: 1px dashed #cbd5e1;
    border-radius: 14px;
}

.timeline-empty-icon {
    font-size: 24px;
    margin-bottom: 8px;
}

.timeline-empty strong {
    font-size: 11px;
    color: #334155;
}

.timeline-empty span {
    margin-top: 4px;
    font-size: 9px;
    color: #94a3b8;
}


.timeline-pic {
    margin-top: 3px;
    font-size: 9px;
    color: #94a3b8;
    font-weight: 600;
}
/* ===============================
RESPONSIVE
================================ */


@media(max-width:900px){


.detail-grid{

    grid-template-columns:1fr;

}



.page-header-card{

    flex-direction:column;

    align-items:flex-start;

    gap:15px;

}


}

</style>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/shahlaqeysha/budget-tracker/resources/views/admin/tasks/show.blade.php ENDPATH**/ ?>