<?php $__env->startSection('content'); ?>
<div class="card">
    <h2>Konfirmasi Pembagian Budget</h2>
    <p>Sistem telah menghitung pembagian secara otomatis berdasarkan aturan persentase. Anda bisa mengubah nominalnya secara manual jika diperlukan.</p>
    
    <div style="background: #e9ecef; padding: 15px; border-radius: 5px; margin-bottom: 20px;">
        <strong>Total Setoran: Rp <?php echo e(number_format($jumlahSetoran, 0, ',', '.')); ?></strong>
    </div>

    <?php if($errors->any()): ?>
        <div style="background: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px; margin-bottom: 15px;">
            <?php echo e($errors->first()); ?>

        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('deposit.storeFinal', $project->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="jumlah_setoran" value="<?php echo e($jumlahSetoran); ?>">
        <input type="hidden" name="tanggal_setoran" value="<?php echo e($request->tanggal_setoran); ?>">

        <table>
            <thead>
                <tr>
                    <th>Divisi</th>
                    <th>Nominal Jatah (Bisa Diedit Manual)</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $defaultDistributions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($dist['nama_divisi']); ?></td>
                    <td>
                        <input type="number" name="distribusi[<?php echo e($dist['division_id']); ?>]" value="<?php echo e($dist['nominal']); ?>" required min="0" style="padding: 8px; width: 200px;">
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        
        <br>
        <button type="submit" class="btn btn-success">Simpan Final ke Database</button>
        <a href="javascript:history.back()" class="btn" style="background: #6c757d;">Kembali</a>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/shahlaqeysha/budget-tracker/resources/views/deposit/preview.blade.php ENDPATH**/ ?>