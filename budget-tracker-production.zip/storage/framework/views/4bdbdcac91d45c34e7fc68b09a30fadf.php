<?php $__env->startSection('content'); ?>


<div class="welcome-card">

<div>

<div class="welcome-label">
UPDATE PROGRESS
</div>


<h1>
<?php echo e($task->nama_tugas); ?>

</h1>


<p>
<?php echo e($task->proyek->nama_proyek ?? '-'); ?>

</p>


</div>



<a href="<?php echo e(route('daily-tracker.index')); ?>"
class="back-btn">

← Kembali

</a>

</div>





<div class="glass-panel">


<h2>
✏️ Tambah Aktivitas
</h2>


<form method="POST"
action="<?php echo e(route('daily-tracker.store',$task->id)); ?>">


<?php echo csrf_field(); ?>



<div class="form-group">

<label>
Aktivitas
</label>


<textarea
name="aktivitas"
rows="4"
required
placeholder="Contoh: Membuat laporan progress proyek">
</textarea>


</div>





<div class="form-group">


<label>
Progress (%)
</label>


<input 
type="number"
name="progres"
min="0"
max="100"
value="<?php echo e($task->progres_persen); ?>"
required>


</div>





<div class="form-group">


<label>
Anggaran Aktivitas
</label>


<input 
type="number"
name="anggaran_aktivitas"
min="0">


</div>





<div class="form-group">


<label>
Catatan
</label>


<textarea
name="catatan"
rows="3"
placeholder="Catatan tambahan">
</textarea>


</div>





<button class="update-btn">

💾 Simpan Progress

</button>



</form>


</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/shahlaqeysha/budget-tracker/resources/views/employee/tracker/update.blade.php ENDPATH**/ ?>