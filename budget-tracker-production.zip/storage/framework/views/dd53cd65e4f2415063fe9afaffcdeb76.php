<?php $__env->startSection('content'); ?>
<div class="card">
    <div style="display: flex; justify-content: space-between; align-items: center;">
        <h2>Daily Tracker: <?php echo e($project->nama_project); ?></h2>
        <a href="<?php echo e(route('tasks.create', $project->id)); ?>" class="btn btn-success">+ Tambah Task Baru</a>
    </div>
    <p><a href="<?php echo e(route('dashboard')); ?>" style="color: #007bff; text-decoration: none;">&larr; Kembali ke Dashboard</a></p>
</div>

<div class="card">
    <h3>Daftar Tugas</h3>
    <table>
        <thead>
            <tr>
                <th>Tanggal</th>
                <th>Task</th>
                <th>PIC</th>
                <th>Prioritas</th>
                <th>Status</th>
                <th>Progress</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e(\Carbon\Carbon::parse($task->tanggal)->format('d/m/y')); ?></td>
                <td><?php echo e($task->nama_task); ?></td>
                <td><?php echo e($task->employee->nama_karyawan ?? '-'); ?></td>
                <td><?php echo e($task->prioritas); ?></td>
                <td><?php echo e($task->status); ?></td>
                <td>
                    <form action="<?php echo e(route('tasks.updateStatus', $task->id)); ?>" method="POST" style="display: flex; gap: 5px;">
                        <?php echo csrf_field(); ?>
                        <input type="number" name="progress_persen" value="<?php echo e($task->progress_persen); ?>" min="0" max="100" style="width: 50px;">
                        <input type="hidden" name="status" value="<?php echo e($task->status); ?>">
                        <button type="submit" class="btn" style="padding: 2px 8px; font-size: 12px; background: #28a745;">Update</button>
                    </form>
                </td>
                <td>
                    <strong><?php echo e($task->progress_persen); ?>%</strong>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="7" style="text-align: center;">Belum ada data tugas.</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/shahlaqeysha/budget-tracker/resources/views/tasks/index.blade.php ENDPATH**/ ?>